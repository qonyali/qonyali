package com.example.halilgnal.mathsolver;

public interface CountDownNumber {
     boolean solveGameNew(int[] numbers, int target);

     Integer getHint();

     boolean checkStep();

     void generateGame();
}