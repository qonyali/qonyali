package com.example.halilgnal.mathsolver;

import java.util.ArrayList;
import java.util.Arrays;

public class Solver {
/*
    public static void main(String[] args){
        int[] numbers = {1,5,6,7,50,100};
        int total = 634;
        Solver sl = new Solver();
        if (sl.findSolution(numbers, numbers.length, total)) {
            sl.printSolution();
        }
    }
*/

    private static Operation[] OPERATIONS = {new Add(), new Subtract(), new Multiply(), new Divide()};
    private ArrayList<String> solution = new ArrayList<>();

    public boolean findSolution(int[] t, int nb, int total) {
        int [] aTmp = Arrays.copyOf(t,t.length);

        for (int i = 0; i < nb; i++) {
            if (aTmp[i] == total) {
                return true;
            }

            for (int j = i + 1; j < nb; j++) {
                for (int k = 0; k < OPERATIONS.length; k++) {
                    int res = OPERATIONS[k].eval(aTmp[i], aTmp[j]);

                    if (res != 0) {
                        int savei = aTmp[i], savej = aTmp[j];
                        aTmp[i] = res;
                        aTmp[j] = aTmp[nb - 1];

                        if (findSolution(aTmp, nb - 1, total)) {
                            solution.add(Math.max(savei, savej) + " " +
                                    OPERATIONS[k].symbol() + " " +
                                    Math.min(savei, savej) + " = " + res);
                            return true;
                        }

                        aTmp[i] = savei;
                        aTmp[j] = savej;
                    }
                }
            }
        }

        return false;
    }

    public String printSolution() {

        solution.add("");
        String aSolution = solution.get(0);
        return aSolution;
        /*
        for (int i = solution.size() - 1; i >= 0; i--) {
            System.out.println(solution.get(i));

        }
        */
    }

}
