package com.example.halilgnal.mathsolver;

import android.app.Activity;
import android.content.ClipData;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import static java.lang.Integer.parseInt;

public class GameActivity extends AppCompatActivity {

    private Game game;
    private HandleGame handleGame;



    private int total;
    private int calculation = 0;
    private int btnId = 0;
    private String calculationText = "", calculationTmp = "";
    private int moveCount = 0;

    private ArrayList<Button> btnGameNumberButtons;
    private Button btnRestart, btnHint, btnSolve;

    private TextView tvCalculateValue, tvCalculatedValue;
    private ImageView ivImageView1, ivImageView2, ivImageView3, ivImageView4;
    private Button currentBtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        game = new GameImpl(QUtil.GameLevel.HARD);
        handleGame = new HandleGameImpl();
        btnGameNumberButtons = new ArrayList<>();

        handleGame.initializeGame(game);
        findResources();
        implementEvents();
        setGame(game);
    }

    private void setGame(Game mathGame) {
        for (int i = 0; i < mathGame.getNumbers().length; i++) {
            btnGameNumberButtons.get(i).setText(""+mathGame.getNumbers()[i]);
            btnGameNumberButtons.get(i).setBackgroundResource(R.drawable.buttonshape);
        }
        tvCalculatedValue.setText("" + mathGame.getTarget());
    }

    private void findResources() {
        for (int i = 0; i < game.getNumbers().length; i++) {
            int btnId = getResources().getIdentifier("button" + (i + 1), "id", getPackageName());
            btnGameNumberButtons.add((Button) findViewById(btnId));
        }


        btnRestart = (Button) findViewById(R.id.btnRestart);
        btnHint = (Button) findViewById(R.id.btnHint);
        btnSolve = (Button) findViewById(R.id.btnSolve);

        tvCalculateValue = (TextView) findViewById(R.id.calculateValue);
        tvCalculatedValue = (TextView) findViewById(R.id.calculatedValue);
//        tvCalculatedValue.setText(game.itsCalculatedValue);

        ivImageView1 = (ImageView) findViewById(R.id.imageView1);
        ivImageView2 = (ImageView) findViewById(R.id.imageView2);
        ivImageView3 = (ImageView) findViewById(R.id.imageView3);
        ivImageView4 = (ImageView) findViewById(R.id.imageView4);
    }

    private void implementEvents() {
        for (int i = 0; i < btnGameNumberButtons.size(); i++) {
            btnGameNumberButtons.get(i).setOnTouchListener(new MyTouchListener());
        }


        ivImageView1.setOnDragListener(new DragListener());
        ivImageView2.setOnDragListener(new DragListener());
        ivImageView3.setOnDragListener(new DragListener());
        ivImageView4.setOnDragListener(new DragListener());

        btnRestart.setOnClickListener(new MyClickListener());
        btnSolve.setOnClickListener(new MyClickListener());
        btnHint.setOnClickListener(new MyClickListener());

    }

    private void resetGame() {
        setGame(game);
        tvCalculateValue.setText("reset");
        implementEvents();
        moveCount = 0;
        calculation = 0;
        total = 0;
    }

    private void disableButton(Button btn) {
        btn.setOnTouchListener(new DeleteTouchListener());
        btn.setBackgroundResource(R.drawable.buttonshape_used);
    }

    public class DragListener extends Activity implements View.OnDragListener {

        @Override
        public boolean onDrag(View v, DragEvent event) {

            final int action = event.getAction();
            switch (action) {
                case DragEvent.ACTION_DRAG_STARTED: {

                    //System.out.println("ACTION_DRAG_STARTED");
                    return true; //Accept
                }
                case DragEvent.ACTION_DRAG_ENDED: {
                    //System.out.println("ACTION_DRAG_ENDED");
                    return true;
                }
                case DragEvent.ACTION_DRAG_ENTERED: {
                    if (v.getId() == R.id.imageView1) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                        //tvCalculateValue.setText("test: " + calculation + " + "+ currentBtn.getText().toString());
                    }
                    if (v.getId() == R.id.imageView2) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                        //tvCalculateValue.setText("test: " + calculation + " - "+ currentBtn.getText().toString());
                    }
                    if (v.getId() == R.id.imageView3) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                    if (v.getId() == R.id.imageView4) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                    //System.out.println("ACTION_DRAG_ENTERED");


                    return true;
                }
                case DragEvent.ACTION_DRAG_EXITED: {
                    if (v.getId() == R.id.imageView1) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                    if (v.getId() == R.id.imageView2) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                    if (v.getId() == R.id.imageView3) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                    if (v.getId() == R.id.imageView4) {
                        v.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                    tvCalculateValue.setText("test: " + calculationText);
                    //System.out.println("ACTION_DRAG_EXITED");
                    return true;
                }
                case DragEvent.ACTION_DROP: {
                    ClipData.Item item = event.getClipData().getItemAt(0);

                    if (calculationText == "") {
                        calculationText += "" + item.getText().toString();
                    }
                    switch (v.getId()) {
                        case R.id.imageView1:
                            total = total + parseInt(item.getText().toString());
                            calculation += parseInt(item.getText().toString());
                            calculationText += " + " + item.getText().toString();
                            break;
                        case R.id.imageView2:
                            total = (total == 0) ? parseInt(item.getText().toString()) : total - parseInt(item.getText().toString());
                            calculation = (calculation == 0) ? parseInt(item.getText().toString()) : calculation - parseInt(item.getText().toString());
                            calculationText += " - " + item.getText().toString();
                            break;
                        case R.id.imageView3:
                            total = (total == 0) ? parseInt(item.getText().toString()) : total * parseInt(item.getText().toString());
                            calculation = (calculation == 0) ? parseInt(item.getText().toString()) : calculation * parseInt(item.getText().toString());
                            calculationText += " * " + item.getText().toString();
                            break;
                        case R.id.imageView4:
                            total = (total == 0) ? parseInt(item.getText().toString()) : total / parseInt(item.getText().toString());
                            calculation = (calculation == 0) ? parseInt(item.getText().toString()) : calculation / parseInt(item.getText().toString());
                            calculationText += " / " + item.getText().toString();
                            break;
                    }

                    tvCalculateValue.setText("test: " + total);

                    disableButton(currentBtn);


                    if (moveCount % 2 == 1) {
                        currentBtn.setOnTouchListener(new MyTouchListener());
                        currentBtn.setText(""+calculation);
                        currentBtn.setBackgroundResource(R.drawable.buttonshape);
                        total = 0;
                        calculation = 0;
                    }
                        moveCount++;

                    return true;
                }
            }
            return false;
        }
    }

    private final class MyTouchListener implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {

            currentBtn = (Button) view;
            ClipData data = ClipData.newPlainText("datalabel", "" + currentBtn.getText());
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(view);
            view.startDrag(data, shadow, view, 0);
            return false;
        }
    }

    private final class DeleteTouchListener implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return false;
        }
    }

    private final class MyClickListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            btnId = view.getId();
            switch (btnId) {
                case R.id.btnRestart:
                    resetGame();
                    break;
                case R.id.btnHint:
                    handleGame.initializeGame(game);

                    findResources();
                    implementEvents();
                    currentBtn = btnGameNumberButtons.get(0);
                    setGame(game);
                    break;
                case R.id.btnSolve:

                    tvCalculateValue.setText(game.getSolution());
                    break;
            }

        }
    }

}