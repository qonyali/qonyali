package com.example.halilgnal.mathsolver;


import android.util.Log;

import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;

public class HandleGameImpl implements HandleGame {

    Solver itsSolver;


    HandleGameImpl(){
        itsSolver = new Solver();
    }

    @Override
    public void initializeGame(Game theGame) {
        try {
            int[] aNumbers = generateNumbers(theGame.getLevel());
            int aTarget = generateTarget(theGame.getLevel());
            theGame.updateGame(aNumbers, aTarget, getSolution());

            while (!isSolvable(theGame)) {
                aNumbers = generateNumbers(theGame.getLevel());
                aTarget = generateTarget(theGame.getLevel());
                theGame.updateGame(aNumbers, aTarget, getSolution());
            }
        }
        catch (Exception e)
        {
            Log.e("Initialization Error", e.getMessage());
        }
    }

    @Override
    public boolean isSolvable(Game theGame)  {
        boolean aSolution = false;
        if(theGame == null)
        {
            throw new NullPointerException("Game object is null");
        }
        /*int[] lstNumbers = new int[QUtil.itsArrayLength];
        //System.arraycopy(Objects.requireNonNull(theGame.getNumbers()),0, lstNumbers, theGame.getNumbers().length);
        for(int i=0; i<QUtil.itsArrayLength; i++){
            lstNumbers[i]=theGame.getNumbers()[i];
        }*/

        aSolution = itsSolver.findSolution(theGame.getNumbers(), theGame.getNumbers().length, theGame.getTarget());
        itsSolver.printSolution();
        return aSolution;
    }

    public String getSolution()
    {
        return itsSolver.printSolution();
    }

    public int generateTarget(QUtil.GameLevel theLevel) throws Exception {
        int aGeneratedNumber;
        switch (theLevel) {
            case VERY_EASY:
                aGeneratedNumber = QUtil.generateNumber(QUtil.itsVeryEasyMin, QUtil.itsVeryEasyMax);
                break;
            case EASY:
                aGeneratedNumber =  QUtil.generateNumber(QUtil.itsEasyMin, QUtil.itsEasyMax);
                break;
            case NORMAL:
                aGeneratedNumber =  QUtil.generateNumber(QUtil.itsNormalMin, QUtil.itsNormalMax);
                break;
            case HARD:
                aGeneratedNumber =  QUtil.generateNumber(QUtil.itsHardMin, QUtil.itsHardMax);
                break;
            case VERY_HARD:
                aGeneratedNumber =  QUtil.generateNumber(QUtil.itsVeryHardMin, QUtil.itsVeryHardMax);
                break;
            default:
                throw new Exception("Cannot generate Target");
        }
        return aGeneratedNumber;
    }

    public int[] generateNumbers(QUtil.GameLevel theLevel) throws Exception {
        int[] lstGeneratedNumbers = new int[QUtil.itsArrayLength];
        int aGeneratedNumbers;

        switch (theLevel) {
            //TODO:
            case VERY_EASY:
                //aGeneratedNumbers = QUtil.generateNumber(QUtil.itsVeryEasyMin, QUtil.itsVeryEasyMax);
                break;
            case EASY:
                //aGeneratedNumbers =  QUtil.generateNumber(QUtil.itsEasyMin, QUtil.itsEasyMax);
                break;
            case NORMAL:
                //generatedNumber =  QUtil.generateNumber(QUtil.itsNormalMin, QUtil.itsNormalMax);
                break;
            case HARD:
                for (int i = 0; i < QUtil.itsArrayLength; i++) {
                    if (i < 4) {
                        aGeneratedNumbers = QUtil.generateNumber(1, 10);
                        if (!QUtil.containsValue(lstGeneratedNumbers, aGeneratedNumbers)) {
                            lstGeneratedNumbers[i] = aGeneratedNumbers;
                        } else {
                            i--;
                        }
                    } else {
                        Collections.shuffle(QUtil.itsHardValues);
                        lstGeneratedNumbers[i] = QUtil.itsHardValues.remove(0);
                    }
                }
                break;
            case VERY_HARD:
                //generatedNumber =  QUtil.generateNumber(QUtil.itsVeryHardMin, QUtil.itsVeryHardMax);
                break;
            default:
                throw new Exception("Cannot generate Target");
        }
        Arrays.sort(lstGeneratedNumbers);
        return lstGeneratedNumbers;
    }


}
