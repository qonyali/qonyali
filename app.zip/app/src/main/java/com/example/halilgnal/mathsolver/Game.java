package com.example.halilgnal.mathsolver;

public interface Game {
    int[] getNumbers();
    int getTarget();
    String getSolution();
    QUtil.GameLevel getLevel();
    void updateGame(int[] theNumbers, int theTarget,String theSolution);
}