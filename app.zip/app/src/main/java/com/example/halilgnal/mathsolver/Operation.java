package com.example.halilgnal.mathsolver;

public interface Operation {

    int eval(int x, int y);

    String symbol();

}
