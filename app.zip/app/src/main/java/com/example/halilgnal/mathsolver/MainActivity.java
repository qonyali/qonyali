package com.example.halilgnal.mathsolver;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnBeginGame;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBeginGame = (Button) findViewById(R.id.btnBeginGame);
        btnBeginGame.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btnBeginGame:
                Intent beginGameIntent = new Intent(this, GameActivity.class);
                startActivity(beginGameIntent);
                this.finish();
        }
    }
}
