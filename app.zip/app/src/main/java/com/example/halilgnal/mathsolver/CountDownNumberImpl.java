package com.example.halilgnal.mathsolver;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class CountDownNumberImpl implements CountDownNumber {

    public int[] itsNumbers;
    public int itsCalculatedValue;
    public String itsDifficulty;
    public String itsSolution = "";

    private final ArrayList<Integer> itsHardValues = new ArrayList<>(Arrays.asList(25, 50, 75, 100));
    CountDownSolver itsCds;

    private final String itsVeryEasy = "VERY_EASY";
    private final String itsEasy = "EASY";
    private final String itsNormal = "NORMAL";
    private final String itsHard = "HARD";
    private final String itsVeryHard = "VERY_HARD";

    private final int itsVeryEasyMin = 1, itsVeryEasyMax = 10;
    private final int itsEasyMin = 10, itsEasyMax = 100;
    private final int itsNormalMin = 100, itsNormalMax = 300;
    private final int itsHardMin = 300, itsHardMax = 1000;
    private final int itsVeryHardMin = 1000, itsVeryHardMax = 10000;


    /**
     * @param numbersSize    1- 6
     * @param difficulty VERY_EASY
     *                      EASY
     *                      NORMAL
     *                      HARD
     *                      VERY_HARD
     */
    public CountDownNumberImpl(int numbersSize, String difficulty) {
        this.itsNumbers = new int[numbersSize];
        this.itsDifficulty = difficulty;
        Collections.shuffle(itsHardValues);

    }

    @Override
    public boolean solveGameNew(int[] numbers, int target) {
        System.out.println("neuer aufruf");
        this.itsCds  = new CountDownSolver();
        itsCds.play(numbers,target);
        itsSolution = "" + itsCds.getSolution();
        if(itsSolution != "")
            return true;
        return false;
    }

    @Override
    public Integer getHint() {
        return null;
    }

    @Override
    public boolean checkStep() {
        return false;
    }

    private boolean containsValue(int[] array,int value){
        int i = 0;
        for (; i < array.length; i++) {
            if(array[i] == value){
                return true;
            }
        }
        return false;
    }

    @Override
    public void generateGame() {
        int generatedNumber;

        //ToDo:
        if (this.itsDifficulty == itsVeryEasy) {
            itsCalculatedValue = QUtil.generateNumber(itsVeryEasyMin, itsVeryEasyMax);
        }
        //ToDo:
        if (this.itsDifficulty == itsEasy) {
            itsCalculatedValue = QUtil.generateNumber(itsEasyMin, itsEasyMax);
        }
        //ToDo:
        if (this.itsDifficulty == itsNormal) {
            itsCalculatedValue = QUtil.generateNumber(itsNormalMin, itsNormalMax);
        }
        if (this.itsDifficulty == itsHard) {
            itsCalculatedValue = QUtil.generateNumber(itsHardMin, itsHardMax);
            for (int i = 0; i < this.itsNumbers.length; i++) {
                if (i < 4) {
                        generatedNumber = QUtil.generateNumber(1, 10);
                    if (!containsValue(itsNumbers, generatedNumber)) {
                        itsNumbers[i] = generatedNumber;
                    } else {
                        i--;
                    }
                } else {
                    itsNumbers[i] = itsHardValues.remove(0);
                }
            }
        }
        //ToDo:
        if (this.itsDifficulty == itsVeryHard) {
            itsCalculatedValue = QUtil.generateNumber(itsVeryHardMin, itsVeryHardMax);
        }
        Arrays.sort(itsNumbers);
    }
}


