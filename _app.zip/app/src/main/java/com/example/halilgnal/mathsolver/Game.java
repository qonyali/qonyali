package com.example.halilgnal.mathsolver;

import android.app.Activity;
import android.content.ClipData;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import static java.lang.Integer.parseInt;

public class Game extends AppCompatActivity {

    private Button btnNo1, btnNo2, btnNo3, btnNo4, btnNo5, btnNo6,btnRestart,btnHint,btnSolve;
    private MathGame mathGame;
    private TextView calculateValue, calculatedValue;
    private ImageView imageView1, imageView2, imageView3, imageView4;
    private Button tempBtn = btnNo1;
    int total;
    int btnId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        mathGame = new MathGame(6);
        findResources();
        setMathGame(mathGame);
        implementEvents();
    }

    private void setMathGame(MathGame mathGame){
        btnNo1.setText(mathGame.numbers.get(0).toString());
        btnNo2.setText(mathGame.numbers.get(1).toString());
        btnNo3.setText(mathGame.numbers.get(2).toString());
        btnNo4.setText(mathGame.numbers.get(3).toString());
        btnNo5.setText(mathGame.numbers.get(4).toString());
        btnNo6.setText(mathGame.numbers.get(5).toString());


        btnNo1.setBackgroundResource(R.drawable.buttonshape);
        btnNo2.setBackgroundResource(R.drawable.buttonshape);
        btnNo3.setBackgroundResource(R.drawable.buttonshape);
        btnNo4.setBackgroundResource(R.drawable.buttonshape);
        btnNo5.setBackgroundResource(R.drawable.buttonshape);
        btnNo6.setBackgroundResource(R.drawable.buttonshape);
        total = 0;
    }

    private void findResources() {
        btnNo1 = (Button) findViewById(R.id.button1);
        btnNo2 = (Button) findViewById(R.id.button2);
        btnNo3 = (Button) findViewById(R.id.button3);
        btnNo4 = (Button) findViewById(R.id.button4);
        btnNo5 = (Button) findViewById(R.id.button5);
        btnNo6 = (Button) findViewById(R.id.button6);
        btnRestart = (Button) findViewById(R.id.btnRestart);
        btnHint  = (Button) findViewById(R.id.btnHint);
        btnSolve  = (Button) findViewById(R.id.btnSolve);

        calculateValue = (TextView) findViewById(R.id.calculateValue);
        calculatedValue = (TextView) findViewById(R.id.calculatedValue);
        calculatedValue.setText(mathGame.calculateValue.toString());

        imageView1 = (ImageView) findViewById(R.id.imageView1);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        imageView3 = (ImageView) findViewById(R.id.imageView3);
        imageView4 = (ImageView) findViewById(R.id.imageView4);
    }

    private void implementEvents() {
        btnNo1.setOnTouchListener(new MyTouchListener());
        btnNo2.setOnTouchListener(new MyTouchListener());
        btnNo3.setOnTouchListener(new MyTouchListener());
        btnNo4.setOnTouchListener(new MyTouchListener());
        btnNo5.setOnTouchListener(new MyTouchListener());
        btnNo6.setOnTouchListener(new MyTouchListener());

        imageView1.setOnDragListener(new DragListener());
        imageView2.setOnDragListener(new DragListener());
        imageView3.setOnDragListener(new DragListener());
        imageView4.setOnDragListener(new DragListener());

        btnRestart.setOnClickListener(new MyClickListener());

    }

    private void resetGame() {
        setMathGame(mathGame);
        calculateValue.setText("reset");
        implementEvents();
    }

    private void disableButton(Button btn) {
        btn.setOnTouchListener(new DeleteTouchListener());
        btn.setBackgroundResource(R.drawable.buttonshape_used);
    }

    public class DragListener extends Activity implements View.OnDragListener {

        @Override
        public boolean onDrag(View v, DragEvent event) {

            final int action = event.getAction();
            switch (action) {
                case DragEvent.ACTION_DRAG_STARTED: {
                    return true; //Accept
                }
                case DragEvent.ACTION_DRAG_ENDED: {
                    return true;
                }
                case DragEvent.ACTION_DRAG_ENTERED: {
                    return true;
                }
                case DragEvent.ACTION_DRAG_EXITED: {
                    return true;
                }
                case DragEvent.ACTION_DROP: {
                    disableButton(tempBtn);
                    if (v.getId() == R.id.imageView1) {
                        ClipData.Item item = event.getClipData().getItemAt(0);
                        if (total == 0) {
                            total = parseInt(item.getText().toString());
                        } else {
                            total = total + parseInt(item.getText().toString());
                        }
                        calculateValue.setText("test: " + total);
                    } else if (v.getId() == R.id.imageView2) {
                        ClipData.Item item = event.getClipData().getItemAt(0);
                        if (total == 0) {
                            total = parseInt(item.getText().toString());
                        } else {
                            total = total - parseInt(item.getText().toString());
                        }
                        calculateValue.setText("test: " + total);
                    } else if (v.getId() == R.id.imageView3) {
                        ClipData.Item item = event.getClipData().getItemAt(0);
                        if (total == 0) {
                            total = parseInt(item.getText().toString());
                        } else {
                            total = total * parseInt(item.getText().toString());
                        }
                        calculateValue.setText("test: " + total);
                    } else if (v.getId() == R.id.imageView4) {
                        ClipData.Item item = event.getClipData().getItemAt(0);
                        if (total == 0) {
                            total = parseInt(item.getText().toString());
                        } else {
                            total = total / parseInt(item.getText().toString());
                        }
                        calculateValue.setText("test: " + total);
                    }

                    if (total == mathGame.calculateValue) {
                        calculateValue.setText("u win");
                    }
                    return true;
                }
            }
            return false;
        }
    }

    private final class MyTouchListener implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            tempBtn = (Button) view;
            ClipData data = ClipData.newPlainText("datalabel", "" + tempBtn.getText());
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(view);
            view.startDrag(data, shadow, view, 0);
            return false;
        }
    }

    private final class DeleteTouchListener implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return false;
        }
    }

    private final class MyClickListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            btnId = view.getId();
            switch (btnId){
                case R.id.btnRestart:
                    resetGame();
                    break;
                case R.id.btnHint:
                    break;
                case R.id.btnSolve:

                    break;
            }

        }
    }

}