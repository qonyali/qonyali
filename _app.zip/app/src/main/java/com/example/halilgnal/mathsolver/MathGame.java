package com.example.halilgnal.mathsolver;

import java.util.ArrayList;

/**
 * Created by Halil Günal on 15.05.2018.
 */

public class MathGame{
    ArrayList<Integer> numbers;
    ArrayList<String> hint;
    Integer calculateValue;
    MathGame(int length){
        numbers = new ArrayList<Integer>(length);
        numbers.add(generateNumber(1,5));
        numbers.add(generateNumber(6,10));
        numbers.add(generateNumber(10,15));
        numbers.add(generateNumber(15,20));
        numbers.add(generateNumber(20,50));
        numbers.add(generateNumber(250,500)/5);

        calculateValue = generateNumber(300,1000);
    }
    public ArrayList<Integer> solveGame(MathGameI mathGame){

        return this.numbers;
    }
    public String getHint(MathGameI mathGame){

        return null;
    }

    private int generateNumber(int min, int max)
    {
        int range = Math.abs(max - min) + 1;
        return (int)(Math.random() * range) + (min <= max ? min : max);
    }
}
