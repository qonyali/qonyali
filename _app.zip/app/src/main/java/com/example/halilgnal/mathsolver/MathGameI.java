package com.example.halilgnal.mathsolver;

import java.util.ArrayList;

/**
 * Created by Halil Günal on 15.05.2018.
 */

public interface MathGameI {
    MathGameI getGame();
    ArrayList<Integer> solveGame(MathGameI mathGame);
    String getHint(MathGameI mathGame);
    Integer genereteNumber();
}
