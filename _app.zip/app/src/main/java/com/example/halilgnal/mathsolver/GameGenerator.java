package com.example.halilgnal.mathsolver;

/**
 * Created by Halil Günal on 15.05.2018.
 */

public interface GameGenerator {
    public void generateGame();

}
